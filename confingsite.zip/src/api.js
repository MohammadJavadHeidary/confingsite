const API_KEY = "$2a$10$6rCT5XakblFCN.qLwMTZ8ewx1x7mRENRGV2hWxVg0ZiiQ2zdml/X2";

const URL = "https://api.jsonbin.io/v3/b/69f76d6c36566621a81e1c5a";

// گرفتن تودوها
export const fetchTodos = async () => {
  try {
    const res = await fetch(`${URL}/latest`, {
      method: "GET",
      headers: {
        "X-Master-Key": API_KEY,
      },
    });

    const data = await res.json();
    console.log("FETCH:", data);

    return data.record?.todos || [];
  } catch (error) {
    console.error("Fetch Error:", error);
    return [];
  }
};

// ذخیره تودوها
export const saveTodos = async (todos) => {
  try {
    const res = await fetch(URL, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "X-Master-Key": API_KEY,
      },
      body: JSON.stringify({
        todos,
      }),
    });

    const data = await res.json();
    console.log("SAVE:", data);

    return data;
  } catch (error) {
    console.error("Save Error:", error);
  }
};