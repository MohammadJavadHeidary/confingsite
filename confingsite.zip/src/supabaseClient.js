import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'آدرس پروژه‌ات در پنل سوپابیس'
const supabaseKey = 'کد مخفی پروژه‌ات'
export const supabase = createClient(supabaseUrl, supabaseKey)
