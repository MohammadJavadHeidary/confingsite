import React, { useState, useEffect } from "react";
import TodoForm from "./TodoForm";
import TodoList from "./TodoList";
import { fetchTodos, saveTodos } from "../api"; // اضافه شد

export default function TodoApp() {
  
  const [todos, setTodos] = useState([]); // تغییر کرد
  const [inpVal, setInpVal] = useState("");
  const [filter, setFilter] = useState("active");

  const [showModal, setShowModal] = useState(false);
  const [selectedId, setSelectedId] = useState(null);

  // 🔥 گرفتن دیتا + sync
  useEffect(() => {
    const load = async () => {
      const data = await fetchTodos();
      setTodos(data);
    };

    load();

    const interval = setInterval(load, 2000);
    return () => clearInterval(interval);
  }, []);

  const filteredTodos = todos.filter((todo) => {
    if (filter === "active") return !todo.sold;
    if (filter === "sold") return todo.sold;
    if (filter === "favorite") return todo.favorite;
    return true; 
  });

  const addTodo = async (description) => {
    if (!inpVal.trim()) return;

    const newTodo = {
      id: Date.now(),
      text: inpVal.slice(0, 25),
      description: description,
      sold: false,
      favorite: false,
    };

    const newTodos = [newTodo, ...todos];
    setTodos(newTodos);
    setInpVal("");

    await saveTodos(newTodos); // 🔥 اضافه شد
  };

  const deleteTodo = async (id) => {
    const newTodos = todos.filter((todo) => todo.id !== id);
    setTodos(newTodos);

    await saveTodos(newTodos); // 🔥
  };

  const openSellModal = (id) => {
    setSelectedId(id);
    setShowModal(true);
  };

  const confirmSell = async () => {
    const newTodos = todos.map((todo) =>
      todo.id === selectedId ? { ...todo, sold: true } : todo
    );

    setTodos(newTodos);
    await saveTodos(newTodos); // 🔥

    setShowModal(false);
    setSelectedId(null);
  };

  const favoriteTodo = async (id) => {
    const newTodos = todos.map((todo) =>
      todo.id === id ? { ...todo, favorite: !todo.favorite } : todo
    );

    setTodos(newTodos);
    await saveTodos(newTodos); // 🔥
  };

  const changeFilter = (type) => {
    setFilter(type);
  };

  const filterBtnBase =
    "px-4 py-2 rounded-full border text-sm font-medium transition-colors";
  const activeStyle = "bg-emerald-500 text-white border-emerald-500";
  const inactiveStyle = "bg-white text-gray-700 border-gray-300";

  return (
    <div className="flex flex-col items-center mt-8 gap-6">
      <TodoForm inpVal={inpVal} setInpVal={setInpVal} addTodo={addTodo} />

      <div className="flex gap-3 mt-4">
        <button
          onClick={() => changeFilter("all")}
          className={`${filterBtnBase} ${
            filter === "all" ? activeStyle : inactiveStyle
          }`}
        >
          All
        </button>
        <button
          onClick={() => changeFilter("active")}
          className={`${filterBtnBase} ${
            filter === "active" ? activeStyle : inactiveStyle
          }`}
        >
          Active
        </button>
        <button
          onClick={() => changeFilter("sold")}
          className={`${filterBtnBase} ${
            filter === "sold" ? activeStyle : inactiveStyle
          }`}
        >
          Sold
        </button>
        <button
          onClick={() => changeFilter("favorite")}
          className={`${filterBtnBase} ${
            filter === "favorite" ? activeStyle : inactiveStyle
          }`}
        >
          Favorite
        </button>
      </div>

      <TodoList
        listOfTodos={filteredTodos}
        deleteTodo={deleteTodo}
        openSellModal={openSellModal}
        favoriteTodo={favoriteTodo}
      />

      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-[320px]">
            <p className="text-lg font-semibold text-gray-800">
              Are you sure you want to mark this as sold?
            </p>

            <div className="flex gap-3 mt-5 justify-center">
              <button
                onClick={confirmSell}
                className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
              >
                Confirm
              </button>

              <button
                onClick={() => {
                  setShowModal(false);
                  setSelectedId(null);
                }}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}